<?php
// Impedisci l'accesso diretto via URL
if (count(get_included_files()) === 1) {
    http_response_code(403);
    die('Accesso diretto non consentito.');
}

/**
 * users_config.php
 * Configurazione degli account e dei profili.
 * Contiene 10 utenti reali con i rispettivi profili e password complesse.
 * La password di ciascun utente segue lo schema: PZ8 + 9 cifre casuali
 */
return [
    'subscription_expiry' => '2027-12-31',
    'users' => [
        'alessandro' => [
            'password' => '$2y$12$5xDZobqzhegEcmSAJvPAJOz3.BUZCdT3nhyNv62Jwzjt/oeaS0zk.', // PZ8928301938
            'profiles' => [
                ['id' => 'ale_main', 'name' => 'ale', 'avatar' => 'ph-user-circle', 'color' => '#00f2fe'],
                ['id' => 'ale_kids', 'name' => 'Bambini', 'avatar' => 'ph-smiley', 'color' => '#00e676'],
                ['id' => 'ale_guest', 'name' => 'Ospiti', 'avatar' => 'ph-users', 'color' => '#ff9800']
            ]
        ],
        'giulia' => [
            'password' => '$2y$12$YPT3JK8xsABFrj8vG2xtU.SiHY4d73xajP/Gz5KX2aJ3kVWjEoIby', // PZ8193840293
            'profiles' => [
                ['id' => 'giu_main', 'name' => 'Giulia', 'avatar' => 'ph-user-circle', 'color' => '#ff2a54'],
                ['id' => 'giu_kids', 'name' => 'Kids', 'avatar' => 'ph-smiley', 'color' => '#00e676'],
                ['id' => 'giu_shared', 'name' => 'Famiglia', 'avatar' => 'ph-users-three', 'color' => '#ab47bc']
            ]
        ],
        'marco' => [
            'password' => '$2y$12$ODfUH65kru2qwP14bEvYKOTePFjguqVvEVHyYLAQgvNW2d..iDVpq', // PZ8729381029
            'profiles' => [
                ['id' => 'mar_main', 'name' => 'Marco', 'avatar' => 'ph-user-circle', 'color' => '#29b6f6'],
                ['id' => 'mar_sport', 'name' => 'Sport', 'avatar' => 'ph-trophy', 'color' => '#ffca28']
            ]
        ],
        'sofia' => [
            'password' => '$2y$12$XDZ6uAASYeWmVFYMgZ4YlexSOhV8FdIF/zS2zPamHP1n5/JXbrlbC', // PZ8384910293
            'profiles' => [
                ['id' => 'sof_main', 'name' => 'Sofia', 'avatar' => 'ph-user-circle', 'color' => '#ec407a'],
                ['id' => 'sof_kids', 'name' => 'Bambini', 'avatar' => 'ph-smiley', 'color' => '#00e676']
            ]
        ],
        'luca' => [
            'password' => '$2y$12$TN1PLmG2tK2gRuooeVnw6.TUsg2V1BmFlxE3fgIpEvS0g.9sDLo1W', // PZ8492019384
            'profiles' => [
                ['id' => 'luc_main', 'name' => 'Luca', 'avatar' => 'ph-user-circle', 'color' => '#26a69a'],
                ['id' => 'luc_cinema', 'name' => 'Cinema', 'avatar' => 'ph-film-strip', 'color' => '#ff7043']
            ]
        ],
        'elena' => [
            'password' => '$2y$12$BsBBKmBqWZ4GHvl9tJYPjeLKT0RHiwJHNuk1JCN1l2bW1IMhvqEoC', // PZ8582938192
            'profiles' => [
                ['id' => 'ele_main', 'name' => 'Elena', 'avatar' => 'ph-user-circle', 'color' => '#78909c']
            ]
        ],
        'francesco' => [
            'password' => '$2y$12$gd6f3EagGehh/ekiCS4QwuXETQk/WlrUdkyLvNIXOhWELJFefl0ei', // PZ8628391029
            'profiles' => [
                ['id' => 'fra_main', 'name' => 'Francesco', 'avatar' => 'ph-user-circle', 'color' => '#5c6bc0'],
                ['id' => 'fra_kids', 'name' => 'Kids', 'avatar' => 'ph-smiley', 'color' => '#00e676']
            ]
        ],
        'valeria' => [
            'password' => '$2y$12$sf8CjGu9hQsOIGbA/zSofuEF.5jdf7eDcI0F3d6E1BPKQ.h0a1whC', // PZ8719283019
            'profiles' => [
                ['id' => 'val_main', 'name' => 'Valeria', 'avatar' => 'ph-user-circle', 'color' => '#8d6e63']
            ]
        ],
        'davide' => [
            'password' => '$2y$12$sBX174FVUXQdqcdR.VbKL.oplY5yykn3Z9XVQWJ/DsiW1cklhW1DO', // PZ8829381023
            'profiles' => [
                ['id' => 'dav_main', 'name' => 'Davide', 'avatar' => 'ph-user-circle', 'color' => '#26c6da'],
                ['id' => 'dav_guest', 'name' => 'Ospiti', 'avatar' => 'ph-users', 'color' => '#ab47bc']
            ]
        ],
        'chiara' => [
            'password' => '$2y$12$xySU6bR.NLnwWojlNRciJOlnFi23Y78qCNhPvYfsHht.OkdhFFwtK', // PZ8928374029
            'profiles' => [
                ['id' => 'chi_main', 'name' => 'Chiara', 'avatar' => 'ph-user-circle', 'color' => '#d4e157']
            ]
        ]
    ]
];
