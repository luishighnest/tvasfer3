<?php
// Avvia sessione e verifica autenticazione
session_start();

// Previeni il caching della pagina da parte del browser
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");

$config_file = __DIR__ . '/users_config.php';
$config = file_exists($config_file) ? require $config_file : [];
$subscription_expiry = $config['subscription_expiry'] ?? '2027-12-31';
if (time() > strtotime($subscription_expiry . ' 23:59:59')) {
    if (isset($_COOKIE['remember_user'])) {
        setcookie('remember_user', '', time() - 3600, '/');
    }
    if (isset($_COOKIE['remember_token'])) {
        setcookie('remember_token', '', time() - 3600, '/');
    }
    session_destroy();
    header('Location: expired.php');
    exit;
}

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: login.php');
    exit;
}
if (!isset($_SESSION['active_profile'])) {
    header('Location: select_profile.php');
    exit;
}
$active_profile = $_SESSION['active_profile'];
$pname_check = isset($active_profile['name']) ? strtolower($active_profile['name']) : '';
$pid_check = isset($active_profile['id']) ? strtolower($active_profile['id']) : '';
$is_kids_profile = (
    strpos($pname_check, 'bambini') !== false || 
    strpos($pname_check, 'kids') !== false || 
    strpos($pid_check, 'bambini') !== false || 
    strpos($pid_check, 'kids') !== false
);

// Legge il JSON EPG dal file aggiornato dallo scraper Python
$epg_file = __DIR__ . '/guida_tv_sky.json';
$epg_data = [];
if (file_exists($epg_file)) {
    $json_raw = file_get_contents($epg_file);
    $epg_data = json_decode($json_raw, true) ?? [];
}
$epg_json = json_encode($epg_data, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG);
$last_update = file_exists($epg_file) ? date('H:i', filemtime($epg_file)) : '--:--';

// Legge il JSON Agenda
$agenda_file = __DIR__ . '/agenda.json';
$agenda_data = [];
if (file_exists($agenda_file)) {
    $agenda_raw = file_get_contents($agenda_file);
    $agenda_data = json_decode($agenda_raw, true) ?? [];
}
$agenda_json = json_encode($agenda_data, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG);
?>
<!DOCTYPE html>
<html lang="it">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>PZ8</title>
  <meta name="description" content="Dashboard StreamHub Premium">
  <link rel="stylesheet" href="css/style.css?v=1.5">
  <style>
    /* OVERRIDE CACHED STYLES PER EVITARE CHE IL RIQUADRO SI ALLARGHI */
    .dashboard-layout .dash-info-area {
      position: relative !important;
      height: 100% !important;
      min-height: 0 !important;
      display: block !important;
    }

    .dashboard-layout .dash-info-card {
      position: absolute !important;
      top: 0 !important;
      left: 0 !important;
      right: 0 !important;
      bottom: 0 !important;
      overflow-y: auto !important;
      margin: 0 !important;
      height: auto !important;
      flex: none !important;
    }

    .dashboard-layout .dash-info-card::-webkit-scrollbar {
      width: 6px;
    }
    .dashboard-layout .dash-info-card::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.1);
      border-radius: 3px;
    }

    @media (max-width: 900px) {
      .dash-agenda-panel {
        grid-column: unset !important;
        width: 100% !important;
        border-radius: var(--radius-sm) !important;
      }
    }
  </style>
  <script src="https://unpkg.com/@phosphor-icons/web"></script>
  <script>
    document.documentElement.classList.add('no-transitions');
    if (localStorage.getItem('theme') === 'light') {
      document.documentElement.classList.add('light-mode');
    }
    window.addEventListener('DOMContentLoaded', () => {
      setTimeout(() => {
        document.documentElement.classList.remove('no-transitions');
      }, 50);
    });
  </script>
</head>

<body class="dashboard-body">

  <!-- EPG e Agenda iniettati lato server da PHP: dati disponibili immediatamente -->
  <script>
    window.__EPG_DATA__    = <?= $epg_json ?>;
    window.__EPG_UPDATED__ = "<?= $last_update ?>";
    window.__AGENDA_DATA__ = <?= $agenda_json ?>;
    window.__ACTIVE_PROFILE_NAME__ = "<?= isset($active_profile['name']) ? addslashes($active_profile['name']) : '' ?>";
    window.__ACTIVE_PROFILE_ID__   = "<?= isset($active_profile['id']) ? addslashes($active_profile['id']) : '' ?>";
  </script>

  <div class="dashboard-layout">
    <script>
      (function() {
        const sidebarHidden = localStorage.getItem('sidebar_hidden') === 'true';
        const guideExpanded = localStorage.getItem('guide_expanded') === 'true';
        const layout = document.querySelector('.dashboard-layout');
        if (sidebarHidden) layout.classList.add('sidebar-hidden');
        if (guideExpanded) layout.classList.add('guide-expanded');
      })();
    </script>

    <!-- Sidebar -->
    <aside class="dash-sidebar">
      <div class="dash-brand">
        <div class="dash-brand-icon"><i class="ph ph-play-circle"></i></div>
        <div class="dash-brand-text">PZ<span>8</span></div>
      </div>
      <div class="dash-clock" id="dash-clock">--:--:--</div>
      <div class="dash-clock-date" id="dash-clock-date"></div>
      <div class="dash-clock-divider"></div>

      <!-- Profilo Attivo -->
      <div class="dash-profile-box" style="background: var(--bg-input); border: 1px solid var(--border-subtle); border-radius: var(--radius-sm); padding: 0.75rem; display: flex; align-items: center; gap: 0.75rem; margin-bottom: 1.2rem; position: relative;">
        <div class="dash-profile-avatar" style="width: 34px; height: 34px; border-radius: 8px; background: <?= $active_profile['color'] ?>15; display: flex; align-items: center; justify-content: center; border: 1px solid <?= $active_profile['color'] ?>40; flex-shrink: 0;">
          <i class="ph <?= htmlspecialchars($active_profile['avatar']) ?>" style="color: <?= $active_profile['color'] ?>; font-size: 1.1rem;"></i>
        </div>
        <div class="dash-profile-info" style="display: flex; flex-direction: column; min-width: 0; flex: 1;">
          <span style="font-size: 0.85rem; font-weight: 700; color: var(--text-primary); white-space: nowrap; overflow: hidden; text-overflow: ellipsis;"><?= htmlspecialchars($active_profile['name']) ?></span>
          <span style="font-size: 0.7rem; color: var(--text-muted); white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">Profilo attivo</span>
        </div>

      </div>

      <div class="dash-cat-title">
        Categorie
        <button id="sidebar-toggle" class="sidebar-toggle" title="Nascondi sidebar">
          <i class="ph ph-sidebar-simple"></i>
        </button>
      </div>
      <div class="dash-cat-list" id="dash-cat-list">
        <!-- Categories injected here -->
      </div>
      <a id="btn-guida-tv" href="guida.php" class="dash-exit"><i class="ph ph-calendar"></i> GUIDA TV</a>
      <!-- Settings Trigger -->
      <button id="open-settings-btn" onclick="document.getElementById('settings-modal').classList.add('open')" class="dash-exit" style="margin-top: 0.8rem; margin-bottom: 0; padding: 0.6rem; background: var(--bg-input); border-color: var(--border-subtle); color: var(--text-primary); border-radius: var(--radius-sm); display: flex; align-items: center; justify-content: center; gap: 0.5rem; width: 100%;"><i class="ph ph-gear"></i> Impostazioni</button>
    </aside>

    <!-- Tasto per riaprire la sidebar (visibile solo quando è nascosta) -->
    <button id="sidebar-show" class="sidebar-show-btn" title="Mostra sidebar">
      <i class="ph ph-sidebar-simple"></i>
    </button>

    <!-- Player Area -->
    <div class="dash-player-area">
      <div class="dash-player-loader" id="player-loader">
        <div class="spinner"></div>
        <div class="loader-text">Connessione al flusso...</div>
      </div>
      <iframe id="player-frame" src="about:blank" allowfullscreen
        allow="autoplay; encrypted-media; fullscreen"></iframe>
    </div>

    <!-- Info Area -->
    <div class="dash-info-area">
      <div class="dash-info-card">
        <h1 class="dash-info-title" id="player-ch-name">Caricamento...</h1>
        <div class="dash-info-meta" id="player-ch-meta"></div>

        <div id="player-ch-now-container">
          <div class="dash-info-now-box">
            <div style="display: flex; align-items: center; justify-content: space-between;">
              <span style="color: #00e676; font-weight: 800; text-transform: uppercase; letter-spacing: 1px; font-size: 0.7rem; background: rgba(0, 230, 118, 0.1); padding: 2px 8px; border-radius: 4px;">IN ONDA LIVE</span>
              <span style="font-family: var(--font-alt); font-size: 0.8rem; color: var(--text-secondary); font-weight: 700;">--:--</span>
            </div>
            <div style="font-size: 1.1rem; font-weight: 800; color: var(--text-primary); line-height: 1.3;">Programmazione in corso</div>
          </div>
        </div>

        <!-- A SEGUIRE container -->
        <div id="player-ch-next-container">
          <div class="dash-info-next-box">
            <div style="display: flex; align-items: center; justify-content: space-between;">
              <span style="color: #60a5fa; font-weight: 800; text-transform: uppercase; letter-spacing: 1px; font-size: 0.7rem; background: rgba(96, 165, 250, 0.1); padding: 2px 8px; border-radius: 4px;">A SEGUIRE</span>
              <span style="font-family: var(--font-alt); font-size: 0.8rem; color: var(--text-secondary); font-weight: 700;">--:--</span>
            </div>
            <div style="font-size: 0.95rem; font-weight: 700; color: var(--text-primary); line-height: 1.3;">Programma successivo in arrivo</div>
          </div>
        </div>
      </div>
    </div>

    <!-- Panels -->
    <div class="dash-panel dash-guide-panel" style="grid-column: <?= $is_kids_profile ? '2 / -1' : '2 / span 2' ?>; grid-row: 2;">
      <div class="dash-panel-header guide"
        style="display: flex; justify-content: space-between; align-items: center; padding: 0.8rem 1.5rem; border-bottom: 1px solid var(--border-subtle);">
        <div style="display: flex; align-items: center; gap: 0.8rem;">
          <span class="dot" style="background: #ef4444; width: 10px; height: 10px; border-radius: 50%; display: inline-block;"></span>
          <span id="panel-cat-title" style="color: #60a5fa; font-weight: 900; font-size: 0.85rem; letter-spacing: 0.5px; text-transform: uppercase;">CANALI LIVE</span>
          <span style="background: rgba(255,255,255,0.08); padding: 2px 8px; border-radius: 12px; font-size: 0.75rem; font-weight: 700; color: var(--text-secondary);" id="ch-count">0</span>
        </div>

        <div style="display: flex; align-items: center; gap: 1rem;">
          <div class="dash-search-container" style="position: relative; width: 300px;">
            <i class="ph ph-magnifying-glass"
              style="position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: var(--text-muted); font-size: 1rem; pointer-events: none;"></i>
            <input type="text" id="dash-search" placeholder="Cerca canale, categoria o evento..."
              style="width: 100%; background: var(--bg-input); border: 1px solid var(--border-subtle); border-radius: 8px; padding: 6px 12px 6px 36px; color: var(--text-primary); font-size: 0.85rem;" />
          </div>


        </div>
      </div>

      <div class="dash-panel-content" id="dash-ch-list" style="padding: 1rem; gap: 0.5rem;">
        <!-- Channels & EPG items injected dynamically -->
      </div>
    </div>

    <!-- Agenda Eventi Panel -->
    <?php if (!$is_kids_profile): ?>
    <div class="dash-panel dash-agenda-panel" style="grid-column: 4; grid-row: 2;">
      <div class="dash-panel-header agenda" style="display: flex; align-items: center; justify-content: space-between; padding: 0.8rem 1.5rem; border-bottom: 1px solid var(--border-subtle);">
        <div style="display: flex; align-items: center; gap: 0.8rem;">
          <span class="dot" style="background: #eab308; width: 10px; height: 10px; border-radius: 50%; display: inline-block;"></span>
          <span style="color: #eab308; font-weight: 900; font-size: 0.85rem; letter-spacing: 0.5px; text-transform: uppercase;">AGENDA EVENTI</span>
        </div>
      </div>
      <div class="dash-panel-content" id="dash-agenda-list" style="padding: 1rem; gap: 0.5rem; overflow-y: auto;">
        <!-- Events populated dynamically by JavaScript from agenda.json -->
      </div>
    </div>
    <?php endif; ?>
  </div>

  <script src="js/channels.js?v=<?= time() ?>"></script>
  <?php 
    $pname_check = isset($active_profile['name']) ? strtolower($active_profile['name']) : '';
    $pid_check = isset($active_profile['id']) ? strtolower($active_profile['id']) : '';
    $is_kids_profile = (
        strpos($pname_check, 'bambini') !== false || 
        strpos($pname_check, 'kids') !== false || 
        strpos($pid_check, 'bambini') !== false || 
        strpos($pid_check, 'kids') !== false
    );
  ?>
  <?php if ($is_kids_profile): ?>
  <script>
    if (typeof CHANNELS !== 'undefined') {
        const kidsChannelsList = ["boing", "k2", "rai gulp", "frisbee", "cartoon network", "dea kids", "nick jr", "boomerang"];
        CHANNELS = CHANNELS.filter(c => kidsChannelsList.some(k => c.name.toLowerCase().includes(k)));
        CHANNELS.forEach(c => c.cat = 'bambini');
        CATEGORIES = {
            bambini: { label: "Bambini", icon: "ph-smiley", color: "#00e676" }
        };
    }
  </script>
  <?php endif; ?>
  <script>
    // ── Clock + Date ──
    function updateClock() {
      const now = new Date();
      document.getElementById('dash-clock').textContent = now.toLocaleTimeString('it-IT', { hour12: false });
      const dateEl = document.getElementById('dash-clock-date');
      if (dateEl) {
        dateEl.textContent = now.toLocaleDateString('it-IT', { weekday: 'short', day: 'numeric', month: 'short' });
      }
    }
    setInterval(updateClock, 1000);
    updateClock();

    // Ripristina stati salvati
    const layout = document.querySelector('.dashboard-layout');
    const sidebarHidden = localStorage.getItem('sidebar_hidden') === 'true';
    const guideExpanded = localStorage.getItem('guide_expanded') === 'true';
    if (sidebarHidden) layout.classList.add('sidebar-hidden');
    if (guideExpanded) {
      layout.classList.add('guide-expanded');
      const guideToggle = document.getElementById('guide-expand-toggle');
      if (guideToggle) {
        const icon = guideToggle.querySelector('i');
        const text = guideToggle.querySelector('span');
        if (icon && text) { icon.className = 'ph ph-arrows-in-simple'; text.textContent = 'Compatta'; }
      }
    }

    // Sidebar Toggle (dentro la sidebar — nasconde)
    const sidebarToggleBtn = document.getElementById('sidebar-toggle');
    // Tasto esterno — riapre la sidebar quando è nascosta
    const sidebarShowBtn = document.getElementById('sidebar-show');

    function setSidebarState(hidden) {
      if (hidden) {
        layout.classList.add('sidebar-hidden');
      } else {
        layout.classList.remove('sidebar-hidden');
      }
      localStorage.setItem('sidebar_hidden', hidden ? 'true' : 'false');
    }

    if (sidebarToggleBtn) {
      sidebarToggleBtn.addEventListener('click', function () {
        setSidebarState(true);
      });
    }

    if (sidebarShowBtn) {
      // Pulse sul tasto "riapri" se la sidebar era già nascosta al caricamento
      if (localStorage.getItem('sidebar_hidden') === 'true') {
        sidebarShowBtn.style.animation = 'sidebar-pulse 2.4s ease-in-out infinite';
      }
      sidebarShowBtn.addEventListener('click', function () {
        setSidebarState(false);
        sidebarShowBtn.style.animation = 'none';
      });
    }

    // Guide Expand Toggle
    const guideToggle = document.getElementById('guide-expand-toggle');
    if (guideToggle) {
      guideToggle.addEventListener('click', function() {
        const isExpanded = layout.classList.toggle('guide-expanded');
        localStorage.setItem('guide_expanded', isExpanded ? 'true' : 'false');
        const icon = guideToggle.querySelector('i');
        const text = guideToggle.querySelector('span');
        if (isExpanded) { icon.className = 'ph ph-arrows-in-simple'; text.textContent = 'Compatta'; }
        else             { icon.className = 'ph ph-arrows-out-simple'; text.textContent = 'Espandi'; }
      });
    }

    // ── Canale iniziale da URL ──
    const params = new URLSearchParams(window.location.search);
    let currentChId = parseInt(params.get('id'));
    let currentChannel = currentChId ? getChannelById(currentChId) : null;
    
    // Determina la categoria di default: 'all' (Tutte) se disponibile, altrimenti la prima disponibile
    const defaultCatKey = Object.keys(CATEGORIES).includes('all') ? 'all' : Object.keys(CATEGORIES)[0];
    let currentCat = currentChannel ? currentChannel.cat : defaultCatKey;

    if (!currentChannel) {
      currentChannel = CHANNELS[0];
      currentCat = defaultCatKey;
    }

    // Link GUIDA TV
    const btnGuidaTv = document.getElementById('btn-guida-tv');
    if (btnGuidaTv) btnGuidaTv.href = `guida.php?id=${currentChannel.id}`;

    document.title = currentChannel.name + ' ';
    document.getElementById('player-ch-name').textContent = currentChannel.name;

    const chMeta = CATEGORIES[currentChannel.cat];
    const metaEl = document.getElementById('player-ch-meta');
    if (metaEl && chMeta) {
      metaEl.innerHTML = `
        <span class="dash-info-ch-num">CH ${currentChannel.id}</span>
        <span class="dash-info-cat-badge" style="background: ${chMeta.color}20; color: ${chMeta.color}; border: 1px solid ${chMeta.color}40;">
          <i class="ph ${chMeta.icon}" style="margin-right: 3px; vertical-align: middle;"></i>${chMeta.label}
        </span>
      `;
    }

    // Player
    const frame = document.getElementById('player-frame');
    const loader = document.getElementById('player-loader');
    frame.src = getStreamUrl(currentChannel);
    frame.onload = () => { loader.style.display = 'none'; };
    setTimeout(() => { loader.style.display = 'none'; }, 5000);

    // ── EPG: usa i dati iniettati da PHP, fetch() solo per aggiornamento ──
    let epgData = window.__EPG_DATA__ || [];
    let epgMap = null;
    const EPG_CACHE_KEY    = 'pz8_epg_cache';
    const EPG_CACHE_TS_KEY = 'pz8_epg_cache_ts';
    const EPG_CACHE_MAX_AGE = 120000; // 2 minuti

    function timeToMinutes(timeStr) {
      if (!timeStr || !timeStr.includes(':')) return 0;
      const [hours, minutes] = timeStr.split(':').map(Number);
      return (hours * 60) + minutes;
    }

    function buildEpgMap() {
      epgMap = new Map();
      if (!epgData || epgData.length === 0) return;
      for (let i = 0; i < epgData.length; i++) {
        const item = epgData[i];
        if (item.canale) epgMap.set(item.canale.toUpperCase(), item);
      }
    }

    function saveEpgToCache() {
      try {
        sessionStorage.setItem(EPG_CACHE_KEY, JSON.stringify(epgData));
        sessionStorage.setItem(EPG_CACHE_TS_KEY, String(Date.now()));
      } catch(e) {}
    }

    // Inizializza con dati PHP (istantaneo)
    buildEpgMap();

    // ── Sidebar Categorie ──
    const catList = document.getElementById('dash-cat-list');

    function restoreIconColors() {
      document.querySelectorAll('.dash-cat-item').forEach(el => {
        el.classList.remove('active');
        const icon = el.querySelector('i');
        if (icon) icon.style.color = el.dataset.color || '';
      });
    }

    Object.keys(CATEGORIES).forEach(key => {
      if (key === 'all') return;
      const c = CATEGORIES[key];
      const count = getChannelsByCategory(key).length;
      const a = document.createElement('a');
      a.href = '#';
      a.dataset.color = c.color;
      a.className = 'dash-cat-item' + (key === currentCat ? ' active' : '');
      a.innerHTML = `<i class="ph ${c.icon}" style="color: ${key === currentCat ? 'var(--text-primary)' : c.color}"></i> ${c.label} <span class="dash-cat-count">${count}</span>`;
      a.onclick = (e) => {
        e.preventDefault();
        renderChannels(key);
        restoreIconColors();
        a.classList.add('active');
        const activeIcon = a.querySelector('i');
        if (activeIcon) activeIcon.style.color = 'var(--text-primary)';
        currentCat = key;
      };
      catList.appendChild(a);
    });

    let pName = window.__ACTIVE_PROFILE_NAME__ ? window.__ACTIVE_PROFILE_NAME__.toLowerCase() : '';
    let pId   = window.__ACTIVE_PROFILE_ID__ ? window.__ACTIVE_PROFILE_ID__.toLowerCase() : '';
    if (!pName.includes('bambini') && !pName.includes('kids') && !pId.includes('bambini') && !pId.includes('kids')) {
      const aAll = document.createElement('a');
      aAll.href = '#';
      aAll.dataset.color = '#FFFF00';
      aAll.className = 'dash-cat-item' + ('all' === currentCat ? ' active' : '');
      const allCount = CHANNELS.length;
      aAll.innerHTML = `<i class="ph ph-squares-four" style="color: ${'all' === currentCat ? 'var(--text-primary)' : '#FFFF00'}"></i> Tutte <span class="dash-cat-count">${allCount}</span>`;
      aAll.onclick = (e) => {
        e.preventDefault();
        renderChannels('all');
        restoreIconColors();
        aAll.classList.add('active');
        const activeIcon = aAll.querySelector('i');
        if (activeIcon) activeIcon.style.color = 'var(--text-primary)';
        currentCat = 'all';
      };
      catList.insertBefore(aAll, catList.firstChild);
    }

    // ── Render Canali ──
    function renderChannels(catKey, searchQuery = '') {
      const list = document.getElementById('dash-ch-list');
      if (!list) return;
      list.innerHTML = '';

      let filtered = getChannelsByCategory(catKey);
      const query = searchQuery.toLowerCase().trim();

      if (query) {
        filtered = filtered.filter(ch => {
          const chNameMatch  = ch.name.toLowerCase().includes(query);
          const chCatMatch   = ch.cat.toLowerCase().includes(query);
          const catLabelMatch = (CATEGORIES[ch.cat] && CATEGORIES[ch.cat].label.toLowerCase().includes(query));
          if (chNameMatch || chCatMatch || catLabelMatch) return true;
          const channelEpgObj = epgMap ? epgMap.get(ch.name.toUpperCase()) : null;
          if (channelEpgObj && channelEpgObj.programmi) {
            return channelEpgObj.programmi.some(p => p.titolo.toLowerCase().includes(query));
          }
          return false;
        });
      }

      document.getElementById('ch-count').textContent = filtered.length;

      const panelTitleEl = document.getElementById('panel-cat-title');
      if (panelTitleEl) {
        panelTitleEl.textContent = catKey === 'all' ? 'TUTTI I CANALI'
          : (CATEGORIES[catKey] ? 'CANALI ' + CATEGORIES[catKey].label.toUpperCase() : 'CANALI LIVE');
      }

      if (filtered.length === 0) {
        const emptyDiv = document.createElement('div');
        emptyDiv.className = 'dash-empty-state';
        emptyDiv.innerHTML = `
          <i class="ph ph-magnifying-glass"></i>
          <div class="dash-empty-title">Nessun canale trovato</div>
          <div class="dash-empty-hint">${query ? 'Nessun risultato per "' + query + '"' : 'Nessun canale in questa categoria'}</div>
        `;
        list.appendChild(emptyDiv);
        return;
      }

      const fragment = document.createDocumentFragment();
      const nowDate    = new Date();
      const nowMinutes = (nowDate.getHours() * 60) + nowDate.getMinutes();

      for (let i = 0; i < filtered.length; i++) {
        const ch       = filtered[i];
        const isPlaying = ch.id === currentChannel.id;
        const a        = document.createElement('a');
        a.href         = `?id=${ch.id}`;
        a.className    = 'dash-ch-row' + (isPlaying ? ' active' : '');

        a.addEventListener('click', (e) => { e.preventDefault(); selectChannel(ch); });

        const channelEpg   = getChannelEpg(ch.name);
        const currentProgram = channelEpg.now;
        const cMeta        = CATEGORIES[ch.cat];
        const catColor     = cMeta ? cMeta.color : '#888';
        a.style.setProperty('--ch-hover-accent', catColor);

        let searchMatchHtml = '';
        const channelEpgObj = epgMap ? epgMap.get(ch.name.toUpperCase()) : null;
        if (query && channelEpgObj && channelEpgObj.programmi) {
          const isChNameMatch    = ch.name.toLowerCase().includes(query);
          const isChCatMatch     = ch.cat.toLowerCase().includes(query) || (cMeta && cMeta.label.toLowerCase().includes(query));
          const isCurrentMatch   = currentProgram && currentProgram.titolo.toLowerCase().includes(query);
          const isNextMatch      = channelEpg.next && channelEpg.next.titolo.toLowerCase().includes(query);
          if (!isChNameMatch && !isChCatMatch && !isCurrentMatch && !isNextMatch) {
            const matchedProg = channelEpgObj.programmi.find(p => p.titolo.toLowerCase().includes(query));
            if (matchedProg) {
              searchMatchHtml = `<div class="dash-ch-search-match" style="font-size:0.75rem;color:#10b981;font-weight:700;margin-top:3px;display:inline-flex;align-items:center;gap:3px;">
                <i class="ph ph-calendar-check" style="font-size:0.85rem"></i>
                In Guida: ${matchedProg.ora} - ${matchedProg.titolo}
              </div>`;
            }
          }
        }

        let html = `<div class="dash-ch-num">${ch.id}</div>`;
        html += `<div class="dash-ch-icon" style="background:${catColor}15;color:${catColor}"><i class="ph ${ch.icon}"></i></div>`;
        html += `<div class="dash-ch-col-info"><div class="dash-ch-name">`;
        if (isPlaying) html += `<span class="dash-ch-live-badge">LIVE</span>`;
        html += `${ch.name}</div><div class="dash-ch-cat" style="color:${catColor}">${cMeta ? cMeta.label : ch.cat}</div>${searchMatchHtml}</div>`;

        if (currentProgram) {
          let startMin = timeToMinutes(currentProgram.ora);
          let endMin   = channelEpg.next ? timeToMinutes(channelEpg.next.ora) : startMin + 120;
          if (endMin < startMin) endMin += 1440;
          let adjNow = nowMinutes;
          if (adjNow < startMin && startMin > 1000) adjNow += 1440;

          const dur = endMin - startMin;
          const rem = Math.max(0, endMin - adjNow);
          const pct = dur > 0 ? Math.min(100, Math.max(0, ((adjNow - startMin) / dur) * 100)) : 100;

          html += `<div class="dash-ch-col-epg">`;
          html += `<div style="display:flex;justify-content:space-between;align-items:baseline;gap:10px">`;
          html += `<span style="font-weight:700;font-size:0.95rem;color:${isPlaying ? 'var(--danger)' : 'var(--text-primary)'};white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${currentProgram.titolo}</span>`;
          html += `<span style="font-family:var(--font-alt);font-size:0.8rem;color:var(--accent);font-weight:700;flex-shrink:0">${currentProgram.ora}</span></div>`;
          html += `<div style="display:flex;align-items:center;gap:10px;margin-top:2px">`;
          html += `<div style="flex:1;height:4px;background:#1a1a24;border-radius:99px;overflow:hidden"><div style="width:${pct}%;height:100%;background:linear-gradient(90deg,#ef4444,#b91c1c);border-radius:99px"></div></div>`;
          html += `<span style="font-size:0.72rem;color:var(--text-muted);flex-shrink:0;font-weight:600">${rem > 0 ? 'Mancano ' + rem + ' min' : 'In conclusione'}</span></div></div>`;

        } else {
          html += `<div class="dash-ch-col-epg" style="justify-content:center;display:flex;flex-direction:column"><div style="font-size:0.85rem;color:var(--text-muted);font-style:italic;font-weight:500">Nessuna informazione guida disponibile</div><div style="font-size:0.72rem;color:var(--text-muted);margin-top:2px">Trasmissione live continua</div></div>`;
        }

        a.innerHTML = html;
        fragment.appendChild(a);
      }
      list.appendChild(fragment);
    }

    // ── EPG Lookup ──
    function getChannelEpg(channelName) {
      if (!epgMap || epgMap.size === 0) return { now: null, next: null };
      const channelEpg = epgMap.get(channelName.toUpperCase());
      if (!channelEpg || !channelEpg.programmi || channelEpg.programmi.length === 0) return { now: null, next: null };

      const now            = new Date();
      const currentMinutes = (now.getHours() * 60) + now.getMinutes();
      let activeIndex      = -1;

      for (let i = 0; i < channelEpg.programmi.length; i++) {
        if (timeToMinutes(channelEpg.programmi[i].ora) <= currentMinutes) { activeIndex = i; }
        else break;
      }
      if (activeIndex === -1 && channelEpg.programmi.length > 0) activeIndex = 0;

      return {
        now: channelEpg.programmi[activeIndex],
        next: activeIndex + 1 < channelEpg.programmi.length ? channelEpg.programmi[activeIndex + 1] : null
      };
    }

    // ── Aggiornamento Info Player ──
    function updatePlayerEpg() {
      if (!currentChannel) return;
      const epg           = getChannelEpg(currentChannel.name);
      const nowContainer  = document.getElementById('player-ch-now-container');
      const nextContainer = document.getElementById('player-ch-next-container');
      if (!nowContainer || !nextContainer) return;

      if (!epg.now) {
        const catMeta = CATEGORIES[currentChannel.cat];
        nowContainer.innerHTML = `
          <div class="dash-info-now-box">
            <div style="display:flex;align-items:center;justify-content:space-between;">
              <span style="color:#00e676;font-weight:800;text-transform:uppercase;letter-spacing:1px;font-size:0.7rem;background:rgba(0,230,118,0.1);padding:2px 8px;border-radius:4px;">LIVE</span>
              <span style="font-family:var(--font-alt);font-size:0.8rem;color:var(--text-secondary);font-weight:700;">Live</span>
            </div>
            <div style="font-size:1.1rem;font-weight:800;color:var(--text-primary);line-height:1.3;margin-top:2px;">Eventi ${catMeta ? catMeta.label : currentChannel.cat}</div>
          </div>`;
        nextContainer.innerHTML = `
          <div class="dash-info-next-box">
            <div style="display:flex;align-items:center;justify-content:space-between;">
              <span style="color:#60a5fa;font-weight:800;text-transform:uppercase;letter-spacing:1px;font-size:0.7rem;background:rgba(96,165,250,0.1);padding:2px 8px;border-radius:4px;">A SEGUIRE</span>
              <span style="font-family:var(--font-alt);font-size:0.8rem;color:var(--text-secondary);font-weight:700;">Live</span>
            </div>
            <div style="font-size:0.95rem;font-weight:700;color:var(--text-primary);line-height:1.3;margin-top:2px;">Programmazione live continua</div>
          </div>`;
        return;
      }

      const now          = new Date();
      let nowMinutes     = (now.getHours() * 60) + now.getMinutes();
      let startMinutes   = timeToMinutes(epg.now.ora);
      let endMinutes     = epg.next ? timeToMinutes(epg.next.ora) : startMinutes + 120;
      if (endMinutes < startMinutes) endMinutes += 1440;
      if (nowMinutes < startMinutes && startMinutes > 1000) nowMinutes += 1440;

      const duration        = endMinutes - startMinutes;
      let elapsed           = nowMinutes - startMinutes;
      if (elapsed < 0) elapsed = 0;
      let remaining         = endMinutes - nowMinutes;
      if (remaining < 0) remaining = 0;
      const progressPercent = duration > 0 ? Math.min(100, Math.max(0, (elapsed / duration) * 100)) : 100;

      nowContainer.innerHTML = `
        <div class="dash-info-now-box">
          <div style="display:flex;align-items:center;justify-content:space-between;">
            <span style="color:#00e676;font-weight:800;text-transform:uppercase;letter-spacing:1px;font-size:0.7rem;background:rgba(0,230,118,0.1);padding:2px 8px;border-radius:4px;display:inline-flex;align-items:center;gap:4px;">
              <span style="width:6px;height:6px;border-radius:50%;background:#00e676;display:inline-block;"></span> LIVE
            </span>
            <span style="font-family:var(--font-alt);font-size:0.8rem;color:var(--accent);font-weight:700;">${epg.now.ora}</span>
          </div>
          <div style="font-size:1.1rem;font-weight:800;color:var(--text-primary);line-height:1.3;margin-top:4px;">${epg.now.titolo}</div>
          ${epg.now.descrizione ? `<div style="font-size:0.85rem;color:var(--text-secondary);margin-top:8px;line-height:1.4;">${epg.now.descrizione}</div>` : ''}
          <div style="display:flex;align-items:center;gap:10px;margin-top:8px;">
            <div style="flex:1;height:4px;background:rgba(255,255,255,0.06);border-radius:99px;overflow:hidden;">
              <div style="width:${progressPercent}%;height:100%;background:linear-gradient(90deg,#00e676,#00b0ff);border-radius:99px;box-shadow:0 0 6px rgba(0,230,118,0.3);"></div>
            </div>
            <span style="font-size:0.72rem;color:var(--text-muted);font-weight:600;flex-shrink:0;">${remaining > 0 ? 'Mancano ' + remaining + ' min' : 'In conclusione'}</span>
          </div>
        </div>`;

      if (epg.next) {
        nextContainer.innerHTML = `
          <div class="dash-info-next-box">
            <div style="display:flex;align-items:center;justify-content:space-between;">
              <span style="color:#60a5fa;font-weight:800;text-transform:uppercase;letter-spacing:1px;font-size:0.7rem;background:rgba(96,165,250,0.1);padding:2px 8px;border-radius:4px;">A SEGUIRE</span>
              <span style="font-family:var(--font-alt);font-size:0.8rem;color:var(--text-secondary);font-weight:700;">${epg.next.ora}</span>
            </div>
            <div style="font-size:0.95rem;font-weight:700;color:var(--text-primary);line-height:1.3;margin-top:4px;">${epg.next.titolo}</div>
            ${epg.next.descrizione ? `<div style="font-size:0.8rem;color:var(--text-muted);margin-top:6px;line-height:1.3;">${epg.next.descrizione}</div>` : ''}
          </div>`;
      } else {
        nextContainer.innerHTML = `
          <div class="dash-info-next-box">
            <div style="display:flex;align-items:center;justify-content:space-between;">
              <span style="color:var(--text-muted);font-weight:800;text-transform:uppercase;letter-spacing:1px;font-size:0.7rem;background:rgba(255,255,255,0.05);padding:2px 8px;border-radius:4px;">A SEGUIRE</span>
              <span style="font-family:var(--font-alt);font-size:0.8rem;color:var(--text-secondary);font-weight:700;">--:--</span>
            </div>
            <div style="font-size:0.95rem;font-weight:700;color:var(--text-muted);font-style:italic;line-height:1.3;margin-top:4px;">Nessun programma successivo</div>
          </div>`;
      }
    }

    // ── Fetch in background (aggiorna ogni 60s) ──
    async function fetchEpgData() {
      try {
        const response = await fetch('epg.php');
        if (!response.ok) throw new Error('EPG fetch failed');
        epgData = await response.json();
        buildEpgMap();
        saveEpgToCache();
        renderChannels(currentCat);
        updatePlayerEpg();
      } catch(err) {
        console.warn('Aggiornamento EPG fallito, uso dati esistenti:', err);
      }
    }

    // Search
    document.getElementById('dash-search').addEventListener('input', (e) => {
      renderChannels(currentCat, e.target.value);
    });

    // ── Renderizza Agenda ──
    function renderAgenda() {
      const container = document.getElementById('dash-agenda-list');
      if (!container) return;
      container.innerHTML = '';
      
      const events = window.__AGENDA_DATA__ || [];
      if (events.length === 0) {
        container.innerHTML = `<div style="font-size: 0.85rem; color: var(--text-muted); text-align: center; padding: 2rem 0;">Nessun evento in agenda per oggi</div>`;
        return;
      }

      events.forEach(event => {
        let channelIds = [];
        if (Array.isArray(event.channel_id)) {
          channelIds = event.channel_id;
        } else if (event.channel_id) {
          channelIds = [event.channel_id];
        }

        const channels = channelIds.map(id => getChannelById(id)).filter(ch => !!ch);
        const primaryColor = channels.length > 0 ? (CATEGORIES[channels[0].cat] ? CATEGORIES[channels[0].cat].color : '#eab308') : '#eab308';

        const row = document.createElement('div');
        row.className = 'dash-event-row';
        row.style.borderLeftColor = primaryColor;
        if (channels.length > 0) {
          row.setAttribute('onclick', `selectChannel(getChannelById(${channels[0].id}));`);
        }

        let badgesHtml = '';
        channels.forEach(ch => {
          const catColor = (CATEGORIES[ch.cat]) ? CATEGORIES[ch.cat].color : '#eab308';
          badgesHtml += `
            <span onclick="event.stopPropagation(); selectChannel(getChannelById(${ch.id}));" 
                  style="background: ${catColor}15; color: ${catColor}; border: 1px solid ${catColor}40; padding: 2px 8px; border-radius: 4px; font-size: 0.7rem; font-weight: 800; text-transform: uppercase; cursor: pointer; display: inline-flex; align-items: center; gap: 4px; transition: all 0.2s;"
                  onmouseover="this.style.background='${catColor}30'" 
                  onmouseout="this.style.background='${catColor}15'">
              <i class="ph ${ch.icon}" style="font-size: 0.8rem;"></i> ${ch.name}
            </span>
          `;
        });

        if (badgesHtml === '') {
          badgesHtml = `<span style="color: #eab308; font-size: 0.72rem; font-weight: 800; text-transform: uppercase;">${event.channel_name || 'Sport'}</span>`;
        }
        
        row.innerHTML = `
          <div class="dash-event-time" style="display: flex; flex-wrap: wrap; gap: 6px; align-items: center; width: 100%;">
            ${badgesHtml}
            <span style="margin-left: auto; font-family: var(--font-alt); font-size: 0.75rem; color: var(--text-muted); font-weight: 700; flex-shrink: 0;">${event.time}</span>
          </div>
          <div class="dash-event-title" style="margin-top: 6px;">${event.title}</div>
          <div class="dash-event-desc">${event.desc || ''}</div>
        `;
        container.appendChild(row);
      });
    }

    // ── Avvio: rendering immediato con dati PHP, poi fetch in background ──
    renderChannels(currentCat);
    updatePlayerEpg();
    renderAgenda();
    // Aggiornamento in background dopo 5s, poi ogni 60s
    setTimeout(() => fetchEpgData(), 5000);
    setInterval(() => fetchEpgData(), 60000);

    // ── Cambio canale dinamico ──
    function selectChannel(ch) {
      if (currentChannel && currentChannel.id === ch.id) return;

      document.querySelectorAll('.dash-ch-row').forEach(row => {
        row.classList.remove('active');
        const badge = row.querySelector('.dash-ch-live-badge');
        if (badge) badge.remove();
      });

      currentChannel = ch;

      document.querySelectorAll('.dash-ch-row').forEach(row => {
        if (row.getAttribute('href') === `?id=${ch.id}`) {
          row.classList.add('active');
          const nameEl = row.querySelector('.dash-ch-name');
          if (nameEl && !nameEl.querySelector('.dash-ch-live-badge')) {
            const badgeSpan = document.createElement('span');
            badgeSpan.className = 'dash-ch-live-badge';
            badgeSpan.textContent = 'LIVE';
            nameEl.insertBefore(badgeSpan, nameEl.firstChild);
          }
        }
      });

      document.title = ch.name + ' ';
      document.getElementById('player-ch-name').textContent = ch.name;

      const chMeta = CATEGORIES[ch.cat];
      const metaEl = document.getElementById('player-ch-meta');
      if (metaEl && chMeta) {
        metaEl.innerHTML = `
          <span class="dash-info-ch-num">CH ${ch.id}</span>
          <span class="dash-info-cat-badge" style="background:${chMeta.color}20;color:${chMeta.color};border:1px solid ${chMeta.color}40;">
            <i class="ph ${chMeta.icon}" style="margin-right:3px;vertical-align:middle;"></i>${chMeta.label}
          </span>`;
      }

      const loader = document.getElementById('player-loader');
      const frame  = document.getElementById('player-frame');
      if (loader) loader.style.display = 'flex';
      if (frame)  frame.src = getStreamUrl(ch);

      updatePlayerEpg();
      history.pushState({ id: ch.id }, '', `?id=${ch.id}`);

      const btnGuidaTv = document.getElementById('btn-guida-tv');
      if (btnGuidaTv) btnGuidaTv.href = `guida.php?id=${ch.id}`;
    }

    // Back/Forward browser
    window.addEventListener('popstate', (e) => {
      const params = new URLSearchParams(window.location.search);
      const id = parseInt(params.get('id'));
      if (id) { const ch = getChannelById(id); if (ch) selectChannel(ch); }
    });
  </script>
  <!-- Settings Modal -->
  <div id="settings-modal" class="settings-modal-overlay">
    <div class="settings-modal-content">
      <div class="settings-modal-header">
        <h2><i class="ph ph-gear"></i> Impostazioni</h2>
        <button id="close-settings-btn" onclick="document.getElementById('settings-modal').classList.remove('open')" class="settings-modal-close">&times;</button>
      </div>
      <div class="settings-modal-body">
        <div class="settings-section">
          <h3><i class="ph ph-palette"></i> Aspetto</h3>
          <div class="settings-row">
            <span>Tema dell'interfaccia</span>
            <button id="theme-toggle" class="settings-theme-btn">
              <i class="ph ph-sun"></i> Modalità
            </button>
          </div>
        </div>
        <div class="settings-section">
          <h3><i class="ph ph-user"></i> Informazioni Profilo</h3>
          <div class="settings-profile-info">
            <div class="settings-profile-avatar" style="width: 42px; height: 42px; border-radius: 8px; background: <?= $active_profile['color'] ?>15; display: flex; align-items: center; justify-content: center; border: 1px solid <?= $active_profile['color'] ?>40; flex-shrink: 0;">
              <i class="ph <?= htmlspecialchars($active_profile['avatar']) ?>" style="color: <?= $active_profile['color'] ?>; font-size: 1.3rem;"></i>
            </div>
            <div class="settings-profile-details">
              <span class="settings-profile-name" style="font-weight: 700; color: var(--text-primary); font-size: 0.95rem;"><?= htmlspecialchars($active_profile['name']) ?></span>
              <span class="settings-profile-status" style="font-size: 0.75rem; color: var(--text-muted);">Profilo attivo</span>
              <span class="settings-profile-extra" style="font-size: 0.75rem; color: #eab308; font-weight: 600; margin-top: 2px;">Scadenza abbonamento: <?= date('d/m/Y', strtotime($subscription_expiry)) ?></span>
            </div>
          </div>
        </div>
        <div class="settings-section">
          <h3><i class="ph ph-gear-six"></i> Azioni Rapide</h3>
          <div class="settings-actions-row">
            <a href="select_profile.php" class="settings-action-btn"><i class="ph ph-user-switch"></i> Cambia Profilo</a>
            <a href="logout.php" class="settings-action-btn logout"><i class="ph ph-sign-out"></i> Esci</a>
          </div>
        </div>
      </div>
    </div>
  </div>

  <script src="js/theme.js?v=1.2"></script>
</body>

</html>
