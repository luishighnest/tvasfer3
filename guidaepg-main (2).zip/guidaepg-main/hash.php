<?php
$user_passwords = [
    'alessandro' => 'PZ8928301938',
    'giulia'     => 'PZ8193840293',
    'marco'      => 'PZ8729381029',
    'sofia'      => 'PZ8384910293',
    'luca'       => 'PZ8492019384',
    'elena'      => 'PZ8582938192',
    'francesco'  => 'PZ8628391029',
    'valeria'    => 'PZ8719283019',
    'davide'     => 'PZ8829381023',
    'chiara'     => 'PZ8928374029'
];

foreach ($user_passwords as $u => $p) {
    echo $u . ' => ' . $p . ' => ' . password_hash($p, PASSWORD_DEFAULT) . "\n";
}
