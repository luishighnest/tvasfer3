/* Base URL per tutti i canali */
const STREAM_BASE = "https://www.chilistream.net/live.php?ch=";

let CHANNELS = [
    // ── TIVUSAT ──
    { id: 1, name: "Rai 1", cat: "tivusat", icon: "ph-television", code: "" },
    { id: 2, name: "Rai 2", cat: "tivusat", icon: "ph-television", code: "" },
    { id: 3, name: "Rai 3", cat: "tivusat", icon: "ph-television", code: "" },
    { id: 4, name: "Rai 4", cat: "tivusat", icon: "ph-television", code: "" },
    { id: 5, name: "Rai 5", cat: "tivusat", icon: "ph-television", code: "" },
    { id: 6, name: "Rete 4", cat: "tivusat", icon: "ph-television", code: "" },
    { id: 7, name: "Canale 5", cat: "tivusat", icon: "ph-television", code: "" },
    { id: 8, name: "Italia 1", cat: "tivusat", icon: "ph-television", code: "" },
    { id: 9, name: "La7", cat: "tivusat", icon: "ph-television", code: "" },
    { id: 10, name: "TV8", cat: "tivusat", icon: "ph-television", code: "" },
    { id: 11, name: "Nove", cat: "tivusat", icon: "ph-television", code: "" },
    { id: 12, name: "20 Mediaset", cat: "tivusat", icon: "ph-television", code: "" },
    { id: 13, name: "Twentyseven", cat: "tivusat", icon: "ph-television", code: "" },
    { id: 14, name: "IRIS", cat: "tivusat", icon: "ph-television", code: "" },
    { id: 15, name: "Rai Movie", cat: "tivusat", icon: "ph-film-strip", code: "" },
    { id: 16, name: "Rai Premium", cat: "tivusat", icon: "ph-television", code: "" },
    { id: 17, name: "La 5", cat: "tivusat", icon: "ph-television", code: "" },
    { id: 18, name: "Real Time", cat: "tivusat", icon: "ph-television", code: "" },
    { id: 19, name: "Food Network", cat: "tivusat", icon: "ph-television", code: "" },
    { id: 20, name: "Focus", cat: "tivusat", icon: "ph-television", code: "" },
    { id: 21, name: "Giallo", cat: "tivusat", icon: "ph-television", code: "" },
    { id: 22, name: "Boing", cat: "tivusat", icon: "ph-television", code: "" },
    { id: 23, name: "K2", cat: "tivusat", icon: "ph-television", code: "" },
    { id: 24, name: "Rai Gulp", cat: "tivusat", icon: "ph-television", code: "" },
    { id: 25, name: "Frisbee", cat: "tivusat", icon: "ph-television", code: "" },
    { id: 26, name: "DMAX", cat: "tivusat", icon: "ph-television", code: "" },
    { id: 27, name: "Rai Sport", cat: "tivusat", icon: "ph-soccer-ball", code: "" },
    { id: 28, name: "Sportitalia", cat: "tivusat", icon: "ph-soccer-ball", code: "" },
    { id: 29, name: "HGTV", cat: "tivusat", icon: "ph-television", code: "" },
    { id: 30, name: "RSI LA 1", cat: "tivusat", icon: "ph-television", code: "" },
    { id: 31, name: "RSI LA 2", cat: "tivusat", icon: "ph-television", code: "" },
    { id: 32, name: "Rai News 24", cat: "tivusat", icon: "ph-newspaper", code: "" },

    // ── TIMVISION ──
    { id: 33, name: "DAZN 1", cat: "timvision", icon: "ph-play-circle", code: "" },

    // ── SKY ITALIA ──
    { id: 34, name: "Sky Sport 24", cat: "sky", icon: "ph-soccer-ball", code: "" },
    { id: 35, name: "Sky Sport Uno", cat: "sky", icon: "ph-soccer-ball", code: "" },
    { id: 36, name: "Sky Sport Calcio", cat: "sky", icon: "ph-soccer-ball", code: "" },
    { id: 37, name: "Sky Sport Tennis", cat: "sky", icon: "ph-tennis-ball", code: "" },
    { id: 38, name: "Sky Sport F1", cat: "sky", icon: "ph-steering-wheel", code: "" },
    { id: 39, name: "Sky Sport Legend", cat: "sky", icon: "ph-star", code: "" },
    { id: 40, name: "Sky Sport MotoGP", cat: "sky", icon: "ph-motorcycle", code: "" },
    { id: 41, name: "Sky Sport Basket", cat: "sky", icon: "ph-basketball", code: "" },
    { id: 42, name: "Sky Sport Arena", cat: "sky", icon: "ph-trophy", code: "" },
    { id: 43, name: "Sky Sport Max", cat: "sky", icon: "ph-fire", code: "" },
    { id: 44, name: "Sky Sport Mix", cat: "sky", icon: "ph-shuffle", code: "" },
    { id: 45, name: "Sky Sport Golf", cat: "sky", icon: "ph-flag", code: "" },
    { id: 46, name: "Sky Sport 251", cat: "sky", icon: "ph-monitor-play", code: "" },
    { id: 47, name: "Sky Sport 252", cat: "sky", icon: "ph-monitor-play", code: "" },
    { id: 48, name: "Sky Sport 253", cat: "sky", icon: "ph-monitor-play", code: "" },
    { id: 49, name: "Sky Sport 254", cat: "sky", icon: "ph-monitor-play", code: "" },
    { id: 50, name: "Sky Sport 255", cat: "sky", icon: "ph-monitor-play", code: "" },
    { id: 51, name: "Sky Sport 256", cat: "sky", icon: "ph-monitor-play", code: "" },
    { id: 52, name: "Sky Sport 257", cat: "sky", icon: "ph-monitor-play", code: "" },
    { id: 53, name: "Sky Sport 258", cat: "sky", icon: "ph-monitor-play", code: "" },
    { id: 54, name: "Sky Sport 259", cat: "sky", icon: "ph-monitor-play", code: "" },

    { id: 55, name: "Sky Cinema Uno", cat: "sky", icon: "ph-film-strip", code: "" },
    { id: 56, name: "Sky Cinema Uno +24", cat: "sky", icon: "ph-film-strip", code: "" },
    { id: 57, name: "Sky Cinema Due", cat: "sky", icon: "ph-film-strip", code: "" },
    { id: 58, name: "Sky Cinema Due +24", cat: "sky", icon: "ph-film-strip", code: "" },
    { id: 59, name: "Sky Cinema Collection", cat: "sky", icon: "ph-film-strip", code: "" },
    { id: 60, name: "Sky Cinema Stories", cat: "sky", icon: "ph-book", code: "" },
    { id: 61, name: "Sky Cinema Family", cat: "sky", icon: "ph-baby", code: "" },
    { id: 62, name: "Sky Cinema Action", cat: "sky", icon: "ph-sword", code: "" },
    { id: 63, name: "Sky Cinema Suspense", cat: "sky", icon: "ph-eye", code: "" },
    { id: 64, name: "Sky Cinema Romance", cat: "sky", icon: "ph-heart", code: "" },
    { id: 65, name: "Sky Cinema Drama", cat: "sky", icon: "ph-masks-theater", code: "" },
    { id: 66, name: "Sky Cinema Comedy", cat: "sky", icon: "ph-smiley", code: "" },

    { id: 67, name: "Sky Uno", cat: "sky", icon: "ph-television", code: "" },
    { id: 68, name: "Sky Atlantic", cat: "sky", icon: "ph-television", code: "" },
    { id: 69, name: "Sky Serie", cat: "sky", icon: "ph-film-slate", code: "" },
    { id: 70, name: "Sky Investigation", cat: "sky", icon: "ph-detective", code: "" },
    { id: 71, name: "Sky Crime", cat: "sky", icon: "ph-fingerprint", code: "" },
    { id: 72, name: "Sky Adventure", cat: "sky", icon: "ph-mountains", code: "" },
    { id: 73, name: "MTV", cat: "sky", icon: "ph-music-notes", code: "" },
    { id: 74, name: "Comedy Central", cat: "sky", icon: "ph-smiley", code: "" },

    { id: 75, name: "Sky Arte", cat: "sky", icon: "ph-paint-brush", code: "" },
    { id: 76, name: "Sky Documentaries", cat: "sky", icon: "ph-book-open-text", code: "" },
    { id: 77, name: "Sky Nature", cat: "sky", icon: "ph-tree", code: "" },
    { id: 78, name: "Discovery Channel", cat: "sky", icon: "ph-globe", code: "" },
    { id: 79, name: "History Channel", cat: "sky", icon: "ph-clock-counter-clockwise", code: "" },

    { id: 80, name: "Cartoon Network", cat: "sky", icon: "ph-television", code: "" },
    { id: 81, name: "Dea Kids", cat: "sky", icon: "ph-television", code: "" },
    { id: 82, name: "Nick Jr", cat: "sky", icon: "ph-television", code: "" },
    { id: 83, name: "Boomerang", cat: "sky", icon: "ph-television", code: "" },

    { id: 84, name: "Sky TG 24", cat: "sky", icon: "ph-newspaper", code: "" }
];

let CATEGORIES = {
    all:       { label: "Tutti i Canali", icon: "ph-squares-four", color: "#FFFF00" },
    sky:       { label: "Sky Italia", icon: "ph-television", color: "#00E676" },
    tivusat:   { label: "TivùSat", icon: "ph-satellite", color: "#E91E63" },
    timvision: { label: "Timvision", icon: "ph-monitor-play", color: "#9C27B0" }
};

function getChannelsByCategory(cat) {
    if (cat === "all") return CHANNELS;
    return CHANNELS.filter(c => c.cat === cat);
}

function getChannelById(id) {
    return CHANNELS.find(c => c.id === parseInt(id));
}

function getStreamUrl(channel) {
    if (!channel || !channel.code) return "";
    return STREAM_BASE + channel.code;
}

