<?php
/**
 * logout.php
 * Esegue il logout distruggendo la sessione e reindirizza alla pagina di login.
 */
session_start();

// Svuota tutte le variabili di sessione
$_SESSION = [];

// Cancella il cookie di sessione se presente
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// Cancella i cookie di "Remember me"
setcookie('remember_user', '', time() - 3600, "/");
setcookie('remember_token', '', time() - 3600, "/");

// Distrugge la sessione
session_destroy();

// Reindirizza al login
header("Location: login.php");
exit;
